// Global Variables
let currentPage = 'home';
let competitions = [];
let dashboardCompetitions = [];
let activityFeed = [];

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    setupNavigation();
    setupMascotAnimations();
    setupBackgroundEffects();
    setupForms();
    setupTabs();
    loadCompetitions();
    loadDashboardData();
    setupPasswordToggles();
    setupProfileEdit();
    
    // Cek hash URL saat pertama kali load
    const initialPage = location.hash.replace('#', '') || 'home';
    showPage(initialPage);

    // Update page saat hash berubah
    window.addEventListener('hashchange', () => {
        const page = location.hash.replace('#', '') || 'home';
        showPage(page);
    });
}

// ✅ FIXED: Notifikasi sederhana
function showNotification(message, type) {
    // Cari elemen notif, kalau belum ada buat
    let notification = document.getElementById('notification');
    if (!notification) {
        notification = document.createElement('div');
        notification.id = 'notification';
        notification.style.position = 'fixed';
        notification.style.top = '20px';
        notification.style.right = '20px';
        notification.style.padding = '10px 15px';
        notification.style.border = '2px solid';
        notification.style.borderRadius = '8px';
        notification.style.background = '#111';
        notification.style.color = '#fff';
        notification.style.zIndex = '2000';
        document.body.appendChild(notification);
    }

    // Warna sesuai type
    if (type === 'success') {
        notification.style.borderColor = '#28a745';
        notification.innerHTML = `<i class="fas fa-check-circle" style="color:#28a745; margin-right:5px;"></i>${message}`;
    } else if (type === 'error') {
        notification.style.borderColor = '#dc3545';
        notification.innerHTML = `<i class="fas fa-exclamation-circle" style="color:#dc3545; margin-right:5px;"></i>${message}`;
    } else {
        notification.style.borderColor = '#00ffff';
        notification.innerHTML = `<i class="fas fa-info-circle" style="color:#00ffff; margin-right:5px;"></i>${message}`;
    }

    // Auto hilang
    setTimeout(() => {
        if (notification) notification.remove();
    }, 3000);
}

// Navigation System
function setupNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    const navToggle = document.getElementById('nav-toggle');
    const navMenu = document.getElementById('nav-menu');

    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const page = link.getAttribute('data-page');
            location.hash = page; // update hash
            showPage(page);
            
            // Close mobile menu
            navMenu.classList.remove('active');
        });
    });

    navToggle.addEventListener('click', () => {
        navMenu.classList.toggle('active');
    });
}

function showPage(pageId) {
    // Hide all pages
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => page.classList.remove('active'));
    
    // Show target page
    const targetPage = document.getElementById(pageId);
    if (targetPage) {
        targetPage.classList.add('active');
        currentPage = pageId;
        
        // Update navigation active state
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('data-page') === pageId) {
                link.classList.add('active');
            }
        });
        
        // Update page title
        updatePageTitle(pageId);
        
        // Trigger page-specific functions
        if (pageId === 'competitions') {
            renderCompetitions();
        } else if (pageId === 'dashboard') {
            renderDashboard();
        }
    }
}

function updatePageTitle(pageId) {
    const titles = {
        'home': 'CyberCat CTF - Capture The Flag Competition',
        'competitions': 'CTF Competitions - CyberCat CTF',
        'dashboard': 'Dashboard - CyberCat CTF',
        'profile': 'Profile Management - CyberCat CTF',
        'signin': 'Sign In - CyberCat CTF',
        'signup': 'Sign Up - CyberCat CTF'
    };
    
    document.title = titles[pageId] || 'CyberCat CTF';
}

// Mascot Animations
function setupMascotAnimations() {
    const speechBubbles = document.querySelectorAll('.speech-bubble span');
    const messages = [
        "Ready to hack the matrix?",
        "Let's pwn some challenges!",
        "Time to show your skills!",
        "Meow-velous hacking ahead!",
        "CTF time, let's go!",
        "Ready for some cyber fun?",
        "Hack the planet, meow!",
        "Let's catch some flags!"
    ];
    
    speechBubbles.forEach(bubble => {
        setInterval(() => {
            const randomMessage = messages[Math.floor(Math.random() * messages.length)];
            typeMessage(bubble, randomMessage);
        }, 8000);
    });
}

function typeMessage(element, message) {
    element.textContent = '';
    let i = 0;
    
    const typeInterval = setInterval(() => {
        element.textContent += message[i];
        i++;
        
        if (i >= message.length) {
            clearInterval(typeInterval);
        }
    }, 100);
}

// Background Effects
function setupBackgroundEffects() {
    setupMatrixRain();
    setupFloatingIcons();
}

function setupMatrixRain() {
    const canvas = document.getElementById('matrix-canvas');
    if (!canvas) return; // ✅ Cegah error kalau canvas belum ada
    const ctx = canvas.getContext('2d');
    
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    
    const matrix = "ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789@#$%^&*()*&^%+-/~{[|`]}";
    const matrixArray = matrix.split("");
    
    const fontSize = 10;
    const columns = canvas.width / fontSize;
    
    const drops = [];
    for (let x = 0; x < columns; x++) {
        drops[x] = 1;
    }
    
    function drawMatrix() {
        ctx.fillStyle = 'rgba(0, 0, 0, 0.04)'; // ini cuma untuk "clear canvas" + efek fading
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        ctx.fillStyle = '#00ffffff'; // ini yang benar-benar dipakai untuk warna huruf
        ctx.font = fontSize + 'px monospace'
        
        for (let i = 0; i < drops.length; i++) {
            const text = matrixArray[Math.floor(Math.random() * matrixArray.length)];
            ctx.fillText(text, i * fontSize, drops[i] * fontSize);
            
            if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
                drops[i] = 0;
            }
            drops[i]++;
        }
    }
    
    setInterval(drawMatrix, 35);
    
    window.addEventListener('resize', () => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    });
}

function setupFloatingIcons() {
    const floatingIcons = document.querySelectorAll('.floating-icon');
    
    floatingIcons.forEach((icon, index) => {
        icon.style.animationDelay = `${index * -2}s`;
        icon.style.left = `${Math.random() * 100}%`;
    });
}

// ⚡ Semua fungsi lain (setupForms, loadCompetitions, renderDashboard, dsb) biarkan sama persis dengan file aslinya
// cukup tambahkan bagian di atas agar website bisa jalan lancar.
